// Plugin versions are pinned directly here because this example is a standalone build, not part
// of the SDK's version catalog. Keep these aligned with the SDK's toolchain (AGP 8.10.x, Kotlin 2.0.x).
plugins {
    id("com.android.application") version "8.10.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
