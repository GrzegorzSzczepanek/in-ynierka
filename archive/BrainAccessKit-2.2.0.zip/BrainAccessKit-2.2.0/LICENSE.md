Copyright (c) 2026 Neurotechnology UAB

License: Proprietary

Software License Agreement of BrainAccessKit software

This Software License Agreement ("Agreement") is made and entered into by and between Neurotechnology UAB, a company registered and operating under the laws of the Republic of Lithuania (company code 120441850, registered address Laisvės pr. 125A, Vilnius, Lithuania) ("Licensor" or "Neurotechnology"), and the licensee ("Licensee"). By downloading, installing, integrating, or using BrainAccessKit — the Kotlin SDK for Android for BrainAccess EEG headsets, comprising the prebuilt library artifacts, the example code and the accompanying documentation (together, the "Software") — Licensee agrees to be bound by the terms of this Agreement.

If Licensee is entering into this Agreement on behalf of a company or other legal entity, Licensee represents that it has the authority to bind that entity to these terms. If Licensee does not have such authority or does not agree with these terms, Licensee must not download, install, integrate, or use the Software.

## License Grant

Licensor grants Licensee a non-exclusive, non-transferable license, terminable only as set out under "Termination" below, to:

1. Install and use the Software on any computer or device.
2. Integrate the Software into Licensee's own software products ("Licensee Products").
3. Distribute the Software solely as an integrated and inseparable part of Licensee Products, subject to all terms of this Agreement.
4. Copy and modify the example code shipped in the `Examples/` directory of the distribution and use the result in Licensee Products.

## Restrictions

Licensee shall not:

1. Reverse engineer, decompile, or disassemble the Software or attempt to derive its source code, except to the extent that applicable law expressly permits such activity notwithstanding this limitation.
2. Distribute, sublicense, rent, lease, or otherwise make the Software available to third parties other than as an integrated and inseparable part of Licensee Products.
3. Remove or alter any copyright or proprietary notices contained in the Software.
4. Distribute Licensee Products that include the Software under end-user terms that are less protective of Neurotechnology than this Agreement. In particular, those terms must prohibit reverse engineering, decompiling, or disassembling of the Software to the extent applicable law permits such a prohibition, and must exclude Neurotechnology's warranties and liability towards end users to the extent applicable law permits.

## Ownership

The Software is licensed, not sold. Neurotechnology retains all ownership, intellectual property rights, and proprietary interests in and to the Software. No rights are granted to Licensee other than those expressly set forth in this Agreement.

## Intended Use

The Software and the BrainAccess EEG headsets it connects to are not medical devices. They are intended for research, scientific, educational, general wellness, or non-clinical development purposes, and are not designed, tested, or certified for medical diagnosis, treatment, therapy, or disease prevention. Licensee is solely responsible for determining whether Licensee Products are subject to medical device, data protection, or other regulation in the jurisdictions where they are made available, and for obtaining any approvals such regulation requires.

## Data

The Software performs no network communication of its own, other than the optional Lab Streaming Layer outlet, which publishes data only on the local network under Licensee's control and only when Licensee Products enable it. The Software transmits no data to Neurotechnology. Licensee is solely responsible for the lawful collection, processing, and protection of any data — including EEG data of natural persons — that Licensee Products process using the Software.

## Export Control and Sanctions Compliance

Licensee acknowledges that the Software and any related technical information or materials may be subject to export control laws and regulations of the European Union, the Republic of Lithuania, and other applicable jurisdictions. Licensee agrees to comply with all relevant export control and sanctions laws and regulations, including but not limited to:

* Not exporting, re-exporting, or transferring the Software to any country, individual, or entity subject to EU or Lithuanian sanctions or embargoes without obtaining prior authorization from the competent authorities.
* Not using the Software for any purposes prohibited by applicable export control laws, including but not limited to activities related to the development, production, or use of weapons of mass destruction, military applications, or any other unauthorized end-uses.
* Providing any required documentation or information requested by Licensor to ensure compliance with export control and sanctions regulations.

Licensee shall indemnify and hold harmless Licensor from and against any claim, loss, liability, or damage suffered or incurred by Licensor arising out of or related to Licensee's non-compliance with this clause.

## Updates and Support

Neurotechnology may, at its discretion, provide updates or support for the Software. Any updates shall be governed by this Agreement unless a separate license is provided. Licensor has no obligation to provide support for the Software, especially concerning its integration into or operation within Licensee Products.

## Warranty Disclaimer

The Software is provided "as is" without any warranties, express or implied, including but not limited to merchantability, fitness for a particular purpose, or non-infringement. Licensor does not warrant that the Software will meet Licensee's requirements or that its operation will be uninterrupted or error-free.

## Limitation of Liability

To the maximum extent permitted by law, Neurotechnology shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of profits, data, or use, arising out of or related to the use or inability to use the Software, even if Licensor has been advised of the possibility of such damages.

## Termination

This Agreement is effective until terminated. Neurotechnology may terminate this Agreement immediately if Licensee breaches any of its terms. Upon termination, Licensee must immediately cease all use of the Software, cease all distribution of the Software (whether standalone or as integrated into Licensee Products), and delete all copies of the Software in its possession or control. End users who obtained copies of Licensee Products before termination may continue to use those copies under their end-user terms. The provisions that by their nature continue and survive will survive any termination of this Agreement.

## Governing Law

This Agreement shall be governed by and construed in accordance with the laws of the Republic of Lithuania.

## Severability

If any provision of this Agreement is held to be unenforceable or invalid, such provision will be changed and interpreted to accomplish the objectives of such provision to the greatest extent possible under applicable law, and the remaining provisions will continue in full force and effect.

## Entire Agreement

This Agreement constitutes the entire agreement between the parties concerning the subject matter hereof and supersedes all prior understandings, agreements, representations, and warranties, both written and oral.

## Third-Party Software

The distribution redistributes third-party components in binary form (the Nordic Semiconductor Android BLE library and liblsl / liblsl-Java). Their licences and the notices those licences require are reproduced in `THIRD-PARTY-NOTICES.md`, shipped next to this file; that file is the single authoritative list. Components the consumer declares itself and that are not shipped in the distribution are listed there as well.

IN WITNESS WHEREOF, Licensee acknowledges acceptance of these terms by installing, integrating, or using the Software.
