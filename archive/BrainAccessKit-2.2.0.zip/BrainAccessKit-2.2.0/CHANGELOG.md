# Changelog — BrainAccessKit

All notable changes to the BrainAccess Kotlin SDK for Android. Versions follow the hosted
documentation at `https://www.brainaccess.ai/documentation/kotlin-sdk/<version>/`.

## 2.2.0 — EXG8, test signal, MIDI/MAXI config blob, config rejection

### Breaking

- **`DeviceHardware.MINI_V3` is now `DeviceHardware.EXG8`**, carried by the new
  **`DeviceModel.EXG8`**. Model Number code 6 — the C core's `MINI_V3` — is the board of the EXG8
  product, advertised as "BA EXG8 <number>", 8 channels, MINI electrode layout, accelerometer and
  gyroscope. There is no MINI V3 product: a development unit on that board still advertising
  "BA MINI" now resolves to `MINI_V2` (EEG decodes; IMU and contact bits do not). `DeviceModel`
  gained an entry, so exhaustive `when` over it needs an `EXG8` branch; `legacyDefault(EXG8)` is
  `EXG8`, its only board.

### Fixed

- **MIDI and MAXI configurations reach the headset.** `PacketCodec.encodeConfig` packed every
  bias bit into one byte (inherited from the legacy `convertConfigToByteArray`); the firmware
  requires one byte per 8 channels and refuses any other blob length. Every MIDI (16 ch) and MAXI
  (32 ch) blob was therefore refused and the headset streamed its defaults — all channels,
  gain 8, impedance off — whatever was configured: channel selection, gain and impedance mode
  never took effect, and a disabled channel shifted every column after it. Verified on MAXI 016
  (fw 3.6.0): the old 35-byte blob with 31 channels active still streamed 32, the 38-byte blob
  streams 31; impedance mode now yields impedance packets.
- **A sample rate without a wire code is rejected** when the `DeviceConfig` is built
  (`DeviceConfig.SUPPORTED_SRATES` = 250, 500, 1000) instead of being encoded as code 0 —
  16 kSPS on the ADS1299.

### Added

- **Test signal** (firmware 3.7.0+): `DeviceSession.stream(outputMode: OutputMode =
  OutputMode.NORMAL)` and `supportsTestSignal`. `OutputMode.TEST_SIGNAL` streams the ADS1299's
  internal square wave on every channel — 3737–3739 µV peak-to-peak, ~1 Hz, the same at every
  gain (measured on the EXG8 board, fw 3.7.0). The headset keeps the mode until power-off,
  whoever set it, so the SDK writes the mode on every start of a headset that has the
  characteristic — NORMAL included — and never writes it to older firmware.
  `BrainAccessError.TestSignalNotSupported` on firmware without it; `IllegalArgumentException`
  with impedance on (the test signal replaces the impedance measurement).
  `GattUuids.OUTPUT_MODE_CHARACTERISTIC`.
- **`BrainAccessError.ConfigRejected`**: firmware 3.7.0 reports a refused config blob as stream
  status 2 and would stream its defaults; `configure()` and `stream()` read the status after every
  config write and fail instead of decoding with the wrong gains. Older firmware never reports 2.
  `BrainAccessError` now has 12 subtypes.
- `BrainAccessLslOutlet(…, outputMode)` publishes `output_mode` (`normal` / `test_signal`) in the
  stream description.
- The capture line carries `mode=`; `captures.json` / golden vectors carry `outputMode` for
  test-signal packets, which form their own cell.

### Licence

- `LICENSE.md` is now titled a Software License Agreement (it licenses integrators, not end
  users). The licence is terminable only on breach, no longer revocable at will; end users of
  Licensee Products distributed before a termination keep using their copies. New restriction 4:
  Licensee Products must ship under end-user terms at least as protective of Neurotechnology
  (no reverse engineering of the SDK, warranty and liability exclusions, both as far as the law
  permits).

### Validation status

- **Real V3 packets (EXG8 board):** MINI 003 (hw 3.0.0, fw 3.7.0, a development unit still
  advertising as MINI; filed under `EXG8`) normal and test-signal cells. The test-signal cell is
  also gated against physics: `DecodeGoldenTest` requires 3738 ± 25 µV peak-to-peak on every
  channel. At rest the accelerometer reads |a| = 9.85 m/s² and the gyroscope a few-tenths-°/s
  bias, confirming the ICM-42670-P scaling. No unit advertising "BA EXG8" has been seen yet.
- **MAXI:** a real impedance cell and a partial-active (31 of 32) normal cell from MAXI 016. The
  2.1.0 "MAXI impedance" vectors were normal packets decoded as impedance (captured with the
  refused blob) and are removed.
- **Impedance:** real impedance cells at 250 and 500 Hz on MINI V2 (MINI 053, fw 3.6.0) and the
  EXG8 board (MINI 003, fw 3.7.0) — the first impedance vectors at a rate other than 250 Hz.
  168 vectors; all earlier vectors remain bit-exact unchanged.
- **Parity with the C core** on the same headset (MINI 003, gain 8, 250 and 500 Hz): per channel
  within 0.2 µV peak-to-peak and 0.34 µV per plateau level; every test-signal period exactly
  256 / 512 samples with no gap. The test signal also shows two limits of the firmware's packet
  encoding that both decoders reproduce — 12-bit deltas wrap beyond ±8188 counts/sample and drift
  −1.5 counts/sample inside each packet (PROTOCOL.md §4a).
- Not covered: MIDI hardware (its 2-byte bias blob follows the firmware source), HALO V3, mixed
  per-channel gains with partial-active configs (PROTOCOL.md "Not yet covered").

## 2.1.0 — hardware generations, IMU in physical units, HALO V3

### Changed (consumer-visible)

- **`EegChunk.accel` is now in m/s²**, not raw sensor counts. 2.0.0 passed the accelerometer's
  int16 counts through unchanged while the LSL outlet labelled them `g`; both now match the
  C/Python SDK (`counts × 9.80665 / countsPerG`, with the sensitivity of the part on the board:
  ADXL343 256 counts/g on V2 boards, ICM-42670-P 16384 counts/g on V3). Consumers that scaled
  counts themselves must stop.
- **`DeviceModel.hasAccel` and `DeviceConfig.hasAccel` are gone.** A model is a montage; whether
  a headset has an IMU is a property of its hardware generation: `DeviceSession.hardware`
  (`DeviceHardware.hasAccel` / `hasGyro`).
- **`BrainAccessLslOutlet`** takes `hasGyro` beside `hasAccel`; accelerometer channels carry
  `unit = "m/s^2"`, the new `Gyro_x/y/z` channels `unit = "deg/s"`. Column layout is now
  `[EEG…][Accel_x/y/z]?[Gyro_x/y/z]?[contact_<label>…]`.
- **LSL accelerometer channels are typed `Accel`** (was `Accelerometer`), the spelling
  BrainAccess Board uses for its own headsets. Board shows a channel in its motion panel only
  when the type is `Accel`/`ACC`, so it recorded a mobile stream's accelerometer but never
  displayed it. Gyroscope channels stay `Gyroscope`. The constants are
  `BrainAccessLslOutlet.ACCEL_TYPE` / `GYRO_TYPE`.
- `EegChunk.of(...)` takes a `DeviceHardware` instead of `hasAccel`; `PacketCodec.decode` /
  `decodeRaw` take an optional `hardware` (default: the model's V2 board). `EegFrame` gains
  `gyro` (raw counts, like `accel` at that layer).

### Added

- **`DeviceHardware`** — the board generation as the headset reports it in the DIS Model Number
  (the C core's `ba_device_model` table: 0 MINI_V2, 1 MIDI, 2 MAXI, 4 HALO, 5 HALO_V2,
  6 MINI_V3, 7 HALO_V3). Resolved on connect (`DeviceSession.hardware`); falls back to the
  model's V2 board when the string is missing, unparseable, or names another montage.
- **HALO V3 / MINI V3 support**: their stream footer carries a gyroscope block before the
  accelerometer block; the decoder sizes the packet accordingly, so V3 packets no longer decode
  as extra EEG samples with garbage contact bits. `EegChunk.gyro` — x/y/z in degrees per second
  (ICM-42670-P at the ±250 dps full scale the firmware programs).
- IMU blocks are addressed from the contact block, not `channelCount / 8` bytes back: identical
  for 8/16/32 channels (the existing golden vectors are unchanged), different for a 4-channel
  HALO, which is exactly the V3 case.
- Golden-vector schema: `config.hardware` and `frames[].gyroHex`; the capture line carries
  `hw=<DeviceHardware>`.

### Validation status

- The V2 boards' decode is unchanged: all 84 real-device golden vectors (HALO V2, MINI, MAXI)
  still pass bit-exact, so the contact-anchored IMU addressing and the footer sizing are proven
  equivalent to the legacy layout wherever a vector exists.
- The **V3 footer (gyro block) and the ICM-42670-P scaling are validated against the C core's
  source and synthetic packets only** — no HALO V3 or MINI V3 packet has been captured yet.
  `tools/CAPTURE.md` describes the capture; the validated decode matrix in `PROTOCOL.md` lists
  V3 under "Not yet covered" until it lands.

## 2.0.0 — first release of this SDK

2.0.0 is the **first shipped version of BrainAccessKit**. The number continues the public
Kotlin SDK line: `kotlin-sdk/1.0.0` was the earlier Kotlin-Multiplatform SDK (`balib`), which
this SDK replaces with a different, non-source-compatible API. There is no upgrade path from
1.0.0 code; start from `Examples/MinimalGUI` and the consume guide (`README.md` in the zip).

### What you get

- **Headless Android SDK**, no UI dependencies: `BrainAccessClient` (scan, connect, adapter
  state), `DeviceSession` (state, battery, charging, device info, contact, missed samples,
  configuration, firmware update), typed `EegChunk` Flows in µV.
- **Models:** HALO (4 ch, 250/500 Hz), MINI (8 ch, 250/500 Hz), MIDI (16 ch, 250 Hz),
  MAXI (32 ch, 250 Hz). No model supports 1000 Hz.
- **Scan while connected; multiple simultaneous sessions** (`BrainAccessClient.sessions`).
- **Per-device configuration persistence.** `ConfigStore` is keyed per headset (`DeviceId`) and
  persists sample rate, gain, active set **and channel labels**; the stored config is re-applied
  on connect. `SharedPreferencesConfigStore` for apps, `InMemoryConfigStore` by default.
- **Signal-integrity contract:** per-channel electrode `contact` on every chunk and as a
  `StateFlow`; `missedSamples` (cumulative device-side gap-filled samples); per-sample
  `isDummy` gap markers plus `EegChunk.streaming(sample)` / `STREAMING_LABEL`, matching the
  C/Python SDK `STREAMING` flag (0 = gap-filled, 1 = received).
- **Impedance modes** (`ImpedanceMode.OFF / HZ_7_8 / HZ_31_2 / DR_DIV4`); impedance streams
  device-computed kΩ.
- **Device info** (DIS: manufacturer, model, hardware/firmware version, serial) and
  **charging state** (SIG Battery Level Status).
- **Firmware update (OTA):** `DeviceSession.updateFirmware(image): Flow<OtaProgress>` +
  `supportsFirmwareUpdate`, with the chunk-size announce, 10 ms pacing and ACK-or-link-drop
  completion semantics the vendor bootloaders require; verified on HALO and MAXI.
- **Typed errors:** `BrainAccessError.{MissingPermission, BluetoothOff, LocationOff, Timeout,
  GattError, Disconnected, NotConnected, OtaNotSupported, OtaRejected, OtaFailed}`.
  `BlePermissions.required` gives the runtime permission set per OS level; the SDK never
  requests permissions itself.
- **Link robustness:** HIGH connection priority + 2M PHY requested on connect (MAXI at
  32 × 250 Hz sits near the balanced-interval budget), unbounded notification buffering in
  `stream()` (a slow collector costs memory, never data), config blob re-written before every
  `STREAM_START` so stream restarts within one connection are reliable.
- **Optional LSL** (`:lsl`, liblsl vendored): `BrainAccessLslOutlet` /
  `DeviceSession.streamToLsl(scope)`. Column layout `[EEG…][Accel_x/y/z]?[contact_<label>…]`
  — the per-electrode `contact_<label>` companions (type `contact`, 1.0 = connected) mirror
  what BrainAccess Board publishes, so Board gates received traces by contact. Requires the
  consumer to declare `net.java.dev.jna:jna:5.14.0@aar`.
- **Wire codec** (`:protocol`, pure JVM) gated by **84 real-device golden decode vectors**
  (HALO 250 normal/impedance + 500 normal, MINI 250/500 normal, MAXI 250 normal/impedance)
  and 12 config-encode vectors. MIDI has no real-device vector yet (no hardware);
  see `protocol/PROTOCOL.md` for the exact matrix and the uncovered cells.

### Distribution

- Shipped as a self-contained zip — never published to a Maven repository: `libs/` (SDK jar +
  aars + `liblsl-Java-release.aar`), consume guide, `LICENSE.md`, `THIRD-PARTY-NOTICES.md`,
  this changelog, and a buildable `Examples/MinimalGUI`.
- Toolchain: Kotlin 2.0.21, AGP 8.10.1, Gradle 8.11.1; minSdk 24, compileSdk 36.

### Known limitations

- MIDI decode is not golden-validated on real packets; impedance vectors exist at 250 Hz only;
  every capture is full-active, so partial-active `contact` alignment is asserted only for
  full-active packets.
- Firmware (out of SDK reach): after roughly five stream sessions in one connection a MAXI may
  drop the link itself and refuse reconnection until power-cycled.
